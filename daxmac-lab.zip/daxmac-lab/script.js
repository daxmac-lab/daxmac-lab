// Minimal by design — the site doesn't need heavy JS to do its job.

// Add a subtle border once the page is scrolled, so the sticky header
// reads as "lifted" rather than just floating.
const header = document.querySelector('.site-header');

function updateHeaderState() {
  if (window.scrollY > 8) {
    header.style.boxShadow = '0 1px 0 rgba(23,24,26,0.06)';
  } else {
    header.style.boxShadow = 'none';
  }
}

window.addEventListener('scroll', updateHeaderState, { passive: true });
updateHeaderState();
