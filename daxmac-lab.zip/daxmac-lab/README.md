# DaxMac

Developer onboarding audit site — built by Goodness Nwajichukwu.

## Before you publish

This is a starting build, not a finished site. Two things still need your input:

1. **Findings section** — the Liveblocks and Svix cards currently have placeholder
   text (`[Insert the verified doc gap...]`). Replace with the actual verified
   finding from each audit: the exact page, the exact assumption, the exact
   production consequence. Keep it to one finding per card, stated as fact only
   because it's confirmed — same rule you already use for cold email.
2. **Finding links** — `Read the full audit →` currently points to `#`.
   Point these at the actual audit write-ups (on your personal portfolio,
   or wherever you're hosting the full reports).

## Publishing to GitHub Pages

1. Create a new repo on GitHub named `daxmac-lab` (or whatever you want the
   repo called — this does not have to match the live domain).
2. Upload these files: `index.html`, `style.css`, `script.js`, and the
   `assets/` folder.
3. In the repo: **Settings → Pages → Source → deploy from branch → main → /root**.
4. Your site goes live at `https://<your-github-username>.github.io/daxmac-lab/`
   (or at the repo root if you name the repo `<username>.github.io` — but
   that name is already used by your personal portfolio, so keep this as a
   separate repo).
5. If you buy a custom domain later, add a `CNAME` file with the domain name
   and point your domain's DNS at GitHub Pages — no site rebuild required.

## Structure

```
daxmac-lab/
├── index.html      — all page content, single scrolling page
├── style.css        — all styling
├── script.js         — minimal JS (header scroll state only)
├── assets/
│   ├── logo.png       — drop your finalized logo file here if you want a
│   │                     raster version; the header currently uses an
│   │                     inline SVG mark so no file is required to launch
│   ├── images/
│   └── icons/
└── README.md
```
